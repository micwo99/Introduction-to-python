def secret_function():
    print( "My username is micwo99 and I realize that not checking the submission response can have consequences for my grade.")
